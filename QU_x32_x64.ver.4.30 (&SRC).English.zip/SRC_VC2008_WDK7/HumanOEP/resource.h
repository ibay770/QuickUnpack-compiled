//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by finder.rc
//
#define IDD_MAINDLG                     101

#define IDC_STATICFILE                  1001
#define IDC_FILENAME                    1002
#define IDC_STATICCOMMAND               1003
#define IDC_COMMAND                     1004
#define IDC_USEINT3                     1005
#define IDC_KILLLOWALLOCK               1006
#define IDC_HOOKALLOCK                  1007
#define IDC_HOOKPROTECT                 1008
#define IDC_NUMOFTHREADS                1009
#define IDC_STATICCREATETHREAD          1010
#define IDC_SECTIONS                    1011
#define IDC_USERANGE                    1012
#define IDC_RANGESTART                  1013
#define IDC_STATICRANGESIZE             1014
#define IDC_RANGESIZE                   1015
#define IDC_STATICMEMSTART              1016
#define IDC_MEMSTART                    1017
#define IDC_STATICMEMEND                1018
#define IDC_MEMEND                      1019
#define IDC_OEP                         1020
#define IDC_DETACH                      1021
#define IDC_DUMP                        1022
#define IDC_EXIT                        1023
#define IDC_STATICFRAME                 1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1
#define _APS_NEXT_SYMED_VALUE           102
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_COMMAND_VALUE         32768
#endif
#endif
